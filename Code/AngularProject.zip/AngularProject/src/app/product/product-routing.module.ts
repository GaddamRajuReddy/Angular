import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductComponent } from './pages/product.component';
import { AddproductComponent } from './pages/addproduct/addproduct.component';

const routes: Routes = [
  { path: '', component: ProductComponent },
  { path: 'addProduct', component: AddproductComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductRoutingModule { }
