import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.scss']
})
export class AddproductComponent implements OnInit {

  constructor(private fb: FormBuilder) { }
  productForm: FormGroup
  submitted = false;
  data = [];
  formData: any;
  ngOnInit(): void {
    this.productForm = this.fb.group({
      productName: ['', Validators.required],
      subProductName: ['', Validators.required]
    });
  }
  get f() { return this.productForm.controls; }
  onSubmit() {
    this.submitted = true;
    this.formData = this.productForm.value;
    this.data.push(this.formData)
    console.log(this.formData)

  }

}
