import { Component, OnInit } from '@angular/core';
import { ProductService } from '../service/product.service'

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
  subProductData: any[];
  productData: any[];
  constructor(private product: ProductService) { }

  ngOnInit(): void {
    this.loadProducts();
    
   
  }
  loadProducts() {
    this.product.getProject().subscribe(item => {
      this.productData = item;
      console.log(this.productData)
    })
  }
  loadSubProducts() {
    this.product.getSubProject().subscribe(item => {
      this.subProductData = item;
      console.log(this.subProductData);
    })
  }
  onProductChange(value: any) {
    this.loadSubProducts();
    let obj = this.subProductData.filter(item => {
      item.Name == value;
      this.subProductData = obj;
      return this.subProductData;
    });
    
  }
}
